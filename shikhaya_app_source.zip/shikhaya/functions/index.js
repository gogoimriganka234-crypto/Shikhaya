const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { GoogleGenerativeAI } = require("@google/generative-ai");

admin.initializeApp();
const db = admin.firestore();

// Gemini API key lives ONLY here (Cloud Functions config / Secret Manager).
// Set it with:  firebase functions:config:set gemini.key="YOUR_KEY"
const GEMINI_KEY = functions.config().gemini?.key;
const genAI = new GoogleGenerativeAI(GEMINI_KEY);

const NOT_IN_SYLLABUS_MSG =
  "এই প্ৰশ্নটো আপোনাৰ পাঠ্যপুথিৰ সিলেবাছৰ বাহিৰৰ। অনুগ্ৰহ কৰি আপোনাৰ কিতাপৰ সৈতে জড়িত প্ৰশ্ন সোধক।";

/** Creates the user's Firestore profile on first sign-in. */
exports.onUserCreate = functions.auth.user().onCreate(async (user) => {
  await db.collection("users").doc(user.uid).set(
    {
      uid: user.uid,
      email: user.email || null,
      xp: 0,
      streak: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
});

/** Cosine similarity between two equal-length vectors. */
function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  return dot / (Math.sqrt(magA) * Math.sqrt(magB) || 1);
}

/**
 * Retrieves the top-k most relevant PDF chunks for a query embedding,
 * scoped to active/published content only.
 * NOTE: brute-force similarity is fine for a moderate number of chunks.
 * Migrate to Firestore vector search or a dedicated vector DB as content grows.
 */
async function retrieveTopChunks(queryEmbedding, subjectId, k = 5) {
  let q = db.collection("pdf_chunks");
  if (subjectId) q = q.where("subjectId", "==", subjectId);
  const snap = await q.get();

  const scored = snap.docs.map((doc) => {
    const data = doc.data();
    return { data, score: cosineSimilarity(queryEmbedding, data.embedding || []) };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, k).map((s) => s.data);
}

/**
 * Callable function: askAI({ message, subjectId? })
 * Auth required. Never trusts client-provided uid/role.
 */
exports.askAI = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userMessage = (data.message || "").toString().trim();
  const subjectId = data.subjectId || null;

  if (!userMessage) {
    throw new functions.https.HttpsError("invalid-argument", "Message is required.");
  }
  if (userMessage.length > 1000) {
    throw new functions.https.HttpsError("invalid-argument", "Message too long.");
  }

  const messagesRef = db.collection("chat_sessions").doc(uid).collection("messages");

  // Save the user's message first.
  await messagesRef.add({
    role: "user",
    text: userMessage,
    citations: [],
    timestamp: new Date().toISOString(),
  });

  // Embed the query.
  const embedModel = genAI.getGenerativeModel({ model: "text-embedding-004" });
  const embedResult = await embedModel.embedContent(userMessage);
  const queryEmbedding = embedResult.embedding.values;

  // Retrieve relevant syllabus chunks.
  const chunks = await retrieveTopChunks(queryEmbedding, subjectId);

  if (chunks.length === 0) {
    await messagesRef.add({
      role: "ai",
      text: NOT_IN_SYLLABUS_MSG,
      citations: [],
      timestamp: new Date().toISOString(),
    });
    return { text: NOT_IN_SYLLABUS_MSG, citations: [] };
  }

  const contextText = chunks
    .map((c, i) => `[${i + 1}] (Chapter: ${c.chapterId}, Page: ${c.pageNumber})\n${c.text}`)
    .join("\n\n");

  // Recent chat history for continuity.
  const historySnap = await messagesRef.orderBy("timestamp", "desc").limit(6).get();
  const history = historySnap.docs
    .reverse()
    .map((d) => `${d.data().role}: ${d.data().text}`)
    .join("\n");

  const systemPrompt = `You are Shikhaya AI. Answer ONLY using the CONTEXT below, which comes from the student's official syllabus. Do not use outside knowledge. Respond in the same language as the question (Assamese or English). Cite the chapter/page you used.

If the answer is not contained in the CONTEXT, reply with EXACTLY this Assamese sentence and nothing else:
"${NOT_IN_SYLLABUS_MSG}"

CONTEXT:
${contextText}

CHAT HISTORY:
${history}`;

  const chatModel = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  const result = await chatModel.generateContent([
    { text: systemPrompt },
    { text: `QUESTION: ${userMessage}` }, // user input isolated from instructions
  ]);

  const aiText = result.response.text().trim();
  const citations = chunks.slice(0, 3).map((c) => ({
    chapterTitle: c.chapterId,
    pageNumber: c.pageNumber,
  }));

  await messagesRef.add({
    role: "ai",
    text: aiText,
    citations,
    timestamp: new Date().toISOString(),
  });

  return { text: aiText, citations };
});
