const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { GoogleGenerativeAI } = require("@google/generative-ai");

admin.initializeApp();
const db = admin.firestore();

// Gemini API key lives ONLY here (Cloud Functions config / Secret Manager).
// Set it with:  firebase functions:config:set gemini.key="YOUR_KEY"
const GEMINI_KEY = functions.config().gemini?.key;
const genAI = new GoogleGenerativeAI(GEMINI_KEY);

const NOT_IN_SYLLABUS_MSG =
  "এই প্ৰশ্নটো আপোনাৰ পাঠ্যপুথিৰ সিলেবাছৰ বাহিৰৰ। অনুগ্ৰহ কৰি আপোনাৰ কিতাপৰ সৈতে জড়িত প্ৰশ্ন সোধক।";

const ADMIN_EMAIL = "gogoimriganka234@gmail.com";

/** Creates the user's Firestore profile and assigns role on first sign-in. */
exports.onUserCreate = functions.auth.user().onCreate(async (user) => {
  const role = user.email === ADMIN_EMAIL ? "admin" : "student";

  await admin.auth().setCustomUserClaims(user.uid, { role });

  await db.collection("users").doc(user.uid).set(
    {
      uid: user.uid,
      email: user.email || null,
      role,
      xp: 0,
      streak: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
});

/**
 * Callable function students/admin call after login to force-refresh their
 * ID token claims if the role was just assigned (avoids waiting up to 1hr
 * for the token to naturally refresh).
 */
exports.refreshRole = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const userRecord = await admin.auth().getUser(context.auth.uid);
  const role = userRecord.email === ADMIN_EMAIL ? "admin" : "student";
  await admin.auth().setCustomUserClaims(context.auth.uid, { role });
  return { role };
});

/** Cosine similarity between two equal-length vectors. */
function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  return dot / (Math.sqrt(magA) * Math.sqrt(magB) || 1);
}

/**
 * Retrieves the top-k most relevant PDF chunks for a query embedding,
 * scoped to active/published content only.
 * NOTE: brute-force similarity is fine for a moderate number of chunks.
 * Migrate to Firestore vector search or a dedicated vector DB as content grows.
 */
async function retrieveTopChunks(queryEmbedding, subjectId, k = 5) {
  let q = db.collection("pdf_chunks");
  if (subjectId) q = q.where("subjectId", "==", subjectId);
  const snap = await q.get();

  const scored = snap.docs.map((doc) => {
    const data = doc.data();
    return { data, score: cosineSimilarity(queryEmbedding, data.embedding || []) };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, k).map((s) => s.data);
}

/**
 * Callable function: askAI({ message, subjectId? })
 * Auth required. Never trusts client-provided uid/role.
 */
exports.askAI = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userMessage = (data.message || "").toString().trim();
  const subjectId = data.subjectId || null;

  if (!userMessage) {
    throw new functions.https.HttpsError("invalid-argument", "Message is required.");
  }
  if (userMessage.length > 1000) {
    throw new functions.https.HttpsError("invalid-argument", "Message too long.");
  }

  const messagesRef = db.collection("chat_sessions").doc(uid).collection("messages");

  // Enforce subject-wise daily question limit, if the admin has set one.
  if (subjectId) {
    const subjectSnap = await db.collection("subjects").doc(subjectId).get();
    const dailyLimit = subjectSnap.exists ? subjectSnap.data().dailyQuestionLimit : null;

    if (dailyLimit && dailyLimit > 0) {
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const todayCountSnap = await messagesRef
        .where("role", "==", "user")
        .where("subjectId", "==", subjectId)
        .where("timestamp", ">=", startOfDay.toISOString())
        .get();

      if (todayCountSnap.size >= dailyLimit) {
        const limitMsg =
          "আপুনি আজিৰ বাবে এই বিষয়টোৰ প্ৰশ্নৰ সীমা শেষ কৰিছে। অনুগ্ৰহ কৰি কাইলৈ আকৌ চেষ্টা কৰক।";
        return { text: limitMsg, citations: [], limitReached: true };
      }
    }
  }

  // Save the user's message first.
  await messagesRef.add({
    role: "user",
    text: userMessage,
    subjectId: subjectId || null,
    citations: [],
    timestamp: new Date().toISOString(),
  });

  // Embed the query.
  const embedModel = genAI.getGenerativeModel({ model: "text-embedding-004" });
  const embedResult = await embedModel.embedContent(userMessage);
  const queryEmbedding = embedResult.embedding.values;

  // Retrieve relevant syllabus chunks.
  const chunks = await retrieveTopChunks(queryEmbedding, subjectId);

  if (chunks.length === 0) {
    await messagesRef.add({
      role: "ai",
      text: NOT_IN_SYLLABUS_MSG,
      citations: [],
      timestamp: new Date().toISOString(),
    });
    return { text: NOT_IN_SYLLABUS_MSG, citations: [] };
  }

  const contextText = chunks
    .map((c, i) => `[${i + 1}] (Chapter: ${c.chapterId}, Page: ${c.pageNumber})\n${c.text}`)
    .join("\n\n");

  // Recent chat history for continuity.
  const historySnap = await messagesRef.orderBy("timestamp", "desc").limit(6).get();
  const history = historySnap.docs
    .reverse()
    .map((d) => `${d.data().role}: ${d.data().text}`)
    .join("\n");

  const systemPrompt = `You are Shikhaya AI. Answer ONLY using the CONTEXT below, which comes from the student's official syllabus. Do not use outside knowledge. Respond in the same language as the question (Assamese or English). Cite the chapter/page you used.

If the answer is not contained in the CONTEXT, reply with EXACTLY this Assamese sentence and nothing else:
"${NOT_IN_SYLLABUS_MSG}"

CONTEXT:
${contextText}

CHAT HISTORY:
${history}`;

  const chatModel = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  const result = await chatModel.generateContent([
    { text: systemPrompt },
    { text: `QUESTION: ${userMessage}` }, // user input isolated from instructions
  ]);

  const aiText = result.response.text().trim();
  const citations = chunks.slice(0, 3).map((c) => ({
    chapterTitle: c.chapterId,
    pageNumber: c.pageNumber,
  }));

  await messagesRef.add({
    role: "ai",
    text: aiText,
    citations,
    timestamp: new Date().toISOString(),
  });

  return { text: aiText, citations };
});

// ============================================================
// ADMIN FUNCTIONS — every one re-verifies role server-side.
// ============================================================

function requireAdmin(context) {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  if (context.auth.token.role !== "admin") {
    throw new functions.https.HttpsError("permission-denied", "Admin only.");
  }
}

/** Create or update a subject. data: { id?, name, description, status, dailyQuestionLimit } */
exports.adminSetSubject = functions.https.onCall(async (data, context) => {
  requireAdmin(context);
  const id = data.id || db.collection("subjects").doc().id;
  await db.collection("subjects").doc(id).set(
    {
      name: data.name,
      description: data.description || "",
      status: data.status || "draft",
      dailyQuestionLimit: data.dailyQuestionLimit || null,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
  return { id };
});

/** Create or update a chapter. data: { id?, subjectId, title, order, status } */
exports.adminSetChapter = functions.https.onCall(async (data, context) => {
  requireAdmin(context);
  const id = data.id || db.collection("chapters").doc().id;
  await db.collection("chapters").doc(id).set(
    {
      subjectId: data.subjectId,
      title: data.title,
      order: data.order || 0,
      status: data.status || "draft",
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
  return { id };
});

/** Delete a document from an admin-manageable collection. */
exports.adminDeleteDoc = functions.https.onCall(async (data, context) => {
  requireAdmin(context);
  const allowed = ["subjects", "chapters", "books"];
  if (!allowed.includes(data.collection)) {
    throw new functions.https.HttpsError("invalid-argument", "Collection not allowed.");
  }
  await db.collection(data.collection).doc(data.id).delete();
  return { deleted: true };
});

/** Broadcast a notification to all students. data: { title, body } */
exports.adminBroadcastNotification = functions.https.onCall(async (data, context) => {
  requireAdmin(context);
  await db.collection("notifications").add({
    title: data.title,
    body: data.body,
    sentAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { sent: true };
});

/**
 * Storage-triggered ingestion pipeline: runs automatically when the admin
 * uploads a PDF to `syllabus_pdfs/{subjectId}/{chapterId}/{bookId}.pdf`.
 * Extracts text, chunks it, embeds each chunk, and stores it for RAG.
 */
exports.onPdfUpload = functions.storage.object().onFinalize(async (object) => {
  const filePath = object.name || "";
  if (!filePath.startsWith("syllabus_pdfs/") || !filePath.endsWith(".pdf")) return;

  const parts = filePath.split("/"); // syllabus_pdfs/{subjectId}/{chapterId}/{bookId}.pdf
  if (parts.length < 4) return;
  const [, subjectId, chapterId, fileName] = parts;
  const bookId = fileName.replace(/\.pdf$/, "");

  const bucket = admin.storage().bucket(object.bucket);
  const [buffer] = await bucket.file(filePath).download();

  const pdfParse = require("pdf-parse");
  const parsed = await pdfParse(buffer);
  const fullText = parsed.text || "";

  // Simple ~500-word chunks with light overlap.
  const words = fullText.split(/\s+/).filter(Boolean);
  const chunkSize = 500;
  const overlap = 50;
  const chunks = [];
  for (let i = 0; i < words.length; i += chunkSize - overlap) {
    chunks.push(words.slice(i, i + chunkSize).join(" "));
    if (i + chunkSize >= words.length) break;
  }

  const embedModel = genAI.getGenerativeModel({ model: "text-embedding-004" });
  const batch = db.batch();

  for (let i = 0; i < chunks.length; i++) {
    const text = chunks[i];
    if (!text.trim()) continue;
    const embedResult = await embedModel.embedContent(text);
    const chunkRef = db.collection("pdf_chunks").doc();
    batch.set(chunkRef, {
      bookId,
      subjectId,
      chapterId,
      pageNumber: i + 1, // approximate; true page mapping needs a richer parser
      text,
      embedding: embedResult.embedding.values,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }
  await batch.commit();

  await db.collection("books").doc(bookId).set(
    {
      subjectId,
      chapterId,
      title: bookId,
      fileUrl: filePath,
      status: "active",
      chunkCount: chunks.length,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
});
