# Shikhaya (শিক্ষা) — Student App

Real, working source for: Auth (Google/Facebook/Phone OTP/Email OTP),
AI Chat (RAG over your syllabus PDFs), and the approved orange/white UI.
**No admin panel yet — student-facing app only, as requested.**

---

## 1. What's included
```
lib/
  core/theme/        # colors + light/dark theme
  core/routing/       # go_router with auth guard
  models/             # ChatMessage, Citation
  services/           # AuthService, ChatService (calls Cloud Functions)
  providers/           # AuthProvider, ChatProvider (state)
  screens/
    splash/, auth/ (login, phone otp, email otp)
    home/ (student shell + bottom nav), library/, chat/, profile/
  widgets/             # BottomGlowScaffold, ChatBubble, ChatInputBar
functions/             # Cloud Functions: onUserCreate, askAI (RAG)
firestore.rules
storage.rules
```

## 2. Before you can build an APK — required setup

1. **Create/open your Firebase project** at console.firebase.google.com.
2. Enable **Authentication** providers: Google, Facebook, Phone, Email link.
3. Enable **Cloud Firestore**, **Storage**, **Functions**, **App Check**.
4. Install FlutterFire CLI and connect this project:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   This generates `lib/firebase_options.dart` — required by `main.dart`, not included here since it's project-specific.
5. For Facebook Login, add your Facebook App ID to `android/app/src/main/res/values/strings.xml` (see `flutter_facebook_auth` package docs).
6. Set your Gemini API key on the backend only (never in the app):
   ```bash
   firebase functions:config:set gemini.key="YOUR_GEMINI_API_KEY"
   ```
7. Deploy backend pieces:
   ```bash
   firebase deploy --only functions,firestore:rules,storage:rules
   ```
8. Enable **App Check** with Play Integrity for your Android app in the Firebase console (matches `main.dart`'s `FirebaseAppCheck.instance.activate(...)`).

## 3. Run / build

```bash
flutter pub get
flutter run                 # test on a device/emulator
flutter build apk --release --obfuscate --split-debug-info=build/debug-info
```

The release APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## 4. Important: PDF content pipeline not yet built
`askAI` will correctly return the "outside syllabus" message until PDFs are
ingested into `pdf_chunks` (with embeddings). That ingestion pipeline is an
admin-side feature — build it when you add the Admin Panel later, following
the Master Blueprint's §8.1 ingestion pipeline spec.

## 5. What's intentionally NOT here
- No admin panel / admin routes / admin Cloud Functions — deferred per your request.
- No quiz screens yet — planned as a later phase (see multi-agent plan, Agent 6).
- No offline PDF caching yet — planned once the library/content pipeline exists.
