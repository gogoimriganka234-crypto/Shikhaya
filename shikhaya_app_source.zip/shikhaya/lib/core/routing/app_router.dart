import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../providers/auth_provider.dart';
import '../../screens/splash/splash_screen.dart';
import '../../screens/auth/login_screen.dart';
import '../../screens/home/student_shell.dart';
import '../../screens/admin/admin_shell.dart';

GoRouter buildRouter(AuthProvider auth) {
  return GoRouter(
    refreshListenable: auth,
    initialLocation: '/',
    redirect: (context, state) {
      final loggingIn = state.matchedLocation == '/login';

      if (auth.status == AuthStatus.unknown) return null; // stay on splash
      if (auth.status == AuthStatus.signedOut) {
        return loggingIn ? null : '/login';
      }

      // signedIn — wait until role is resolved before routing further
      if (auth.role == null) return null;

      final wantsAdmin = state.matchedLocation.startsWith('/admin');
      if (auth.isAdmin) {
        if (loggingIn || state.matchedLocation == '/' || !wantsAdmin) return '/admin';
        return null;
      } else {
        if (loggingIn || state.matchedLocation == '/' || wantsAdmin) return '/home';
        return null;
      }
    },
    routes: [
      GoRoute(path: '/', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/home', builder: (_, __) => const StudentShell()),
      GoRoute(path: '/admin', builder: (_, __) => const AdminShell()),
    ],
  );
}
