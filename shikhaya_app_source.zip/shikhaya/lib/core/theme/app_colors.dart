import 'package:flutter/material.dart';

/// Shikhaya brand colors — orange + white theme.
class AppColors {
  AppColors._();

  static const orange = Color(0xFFFF6F00);
  static const orangeSoft = Color(0xFFFF8F3D);
  static const orangeLight = Color(0xFFFFB066);

  static const bg = Color(0xFFFFFFFF);
  static const surface = Color(0xFFFFF8F2);
  static const bubbleUser = Color(0xFFFFF3E0);
  static const bubbleAi = Color(0xFFF7F7F7);

  static const darkOrbBg = Color(0xFF0E0A08);

  static const text = Color(0xFF1A1A1A);
  static const muted = Color(0xFF9A9691);
  static const border = Color(0xFFFBEADC);

  // Dark mode
  static const darkBg = Color(0xFF121212);
  static const darkSurface = Color(0xFF1E1E1E);
}
