import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AdminService {
  final FirebaseFunctions _functions = FirebaseFunctions.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> subjectsStream() {
    return _db.collection('subjects').orderBy('name').snapshots().map(
          (s) => s.docs.map((d) => {...d.data(), 'id': d.id}).toList(),
        );
  }

  Stream<List<Map<String, dynamic>>> chaptersStream(String subjectId) {
    return _db
        .collection('chapters')
        .where('subjectId', isEqualTo: subjectId)
        .orderBy('order')
        .snapshots()
        .map((s) => s.docs.map((d) => {...d.data(), 'id': d.id}).toList());
  }

  Future<String> setSubject({
    String? id,
    required String name,
    required String description,
    required String status,
    int? dailyQuestionLimit,
  }) async {
    final result = await _functions.httpsCallable('adminSetSubject').call({
      'id': id,
      'name': name,
      'description': description,
      'status': status,
      'dailyQuestionLimit': dailyQuestionLimit,
    });
    return result.data['id'] as String;
  }

  Future<String> setChapter({
    String? id,
    required String subjectId,
    required String title,
    required int order,
    required String status,
  }) async {
    final result = await _functions.httpsCallable('adminSetChapter').call({
      'id': id,
      'subjectId': subjectId,
      'title': title,
      'order': order,
      'status': status,
    });
    return result.data['id'] as String;
  }

  Future<void> deleteDoc(String collection, String id) async {
    await _functions.httpsCallable('adminDeleteDoc').call({
      'collection': collection,
      'id': id,
    });
  }

  Future<void> broadcastNotification(String title, String body) async {
    await _functions.httpsCallable('adminBroadcastNotification').call({
      'title': title,
      'body': body,
    });
  }

  /// Uploads a PDF; the Cloud Function `onPdfUpload` picks it up
  /// automatically from Storage and indexes it for the AI.
  Future<void> uploadPdf({
    required File file,
    required String subjectId,
    required String chapterId,
    required String bookId,
  }) async {
    final ref = FirebaseStorage.instance
        .ref('syllabus_pdfs/$subjectId/$chapterId/$bookId.pdf');
    await ref.putFile(file);
  }
}
