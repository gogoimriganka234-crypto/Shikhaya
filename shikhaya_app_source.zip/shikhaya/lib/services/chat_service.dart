import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/chat_message.dart';

/// Talks ONLY to the Cloud Function `askAI`. The Gemini API key never
/// touches this app — it lives in Cloud Functions config/Secret Manager.
class ChatService {
  final FirebaseFunctions _functions = FirebaseFunctions.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  String? get _uid => FirebaseAuth.instance.currentUser?.uid;

  /// Streams this student's chat history (most recent last).
  Stream<List<ChatMessage>> messageStream() {
    final uid = _uid;
    if (uid == null) return const Stream.empty();
    return _db
        .collection('chat_sessions')
        .doc(uid)
        .collection('messages')
        .orderBy('timestamp')
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => ChatMessage.fromMap(d.id, d.data())).toList());
  }

  /// Sends a question to the RAG pipeline and returns the AI's answer.
  /// The Cloud Function handles: auth check, embedding, retrieval,
  /// prompt construction, Gemini call, and saving both messages.
  Future<void> sendMessage(String text, {String? subjectId}) async {
    if (_uid == null) throw StateError('Not signed in');

    final callable = _functions.httpsCallable('askAI');
    await callable.call({
      'message': text,
      'subjectId': subjectId,
    });
    // The Cloud Function writes both the user message and the AI reply
    // to chat_sessions/{uid}/messages — the stream above picks them up
    // automatically, no need to write from the client.
  }
}
