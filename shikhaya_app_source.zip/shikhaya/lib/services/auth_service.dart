import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';

/// Handles all sign-in methods. Never decides admin/student role here —
/// that is determined server-side (Cloud Function) and read from the
/// verified ID token's custom claim.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Google Sign-In
  Future<UserCredential?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final result = await _auth.signInWithCredential(credential);
    await _ensureUserDoc(result.user);
    return result;
  }

  /// Facebook Login
  Future<UserCredential?> signInWithFacebook() async {
    final loginResult = await FacebookAuth.instance.login();
    if (loginResult.status != LoginStatus.success) return null;

    final credential =
        FacebookAuthProvider.credential(loginResult.accessToken!.tokenString);
    final result = await _auth.signInWithCredential(credential);
    await _ensureUserDoc(result.user);
    return result;
  }

  /// Phone OTP — step 1: send code
  Future<void> sendPhoneOtp({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(FirebaseAuthException e) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) async {
        final result = await _auth.signInWithCredential(credential);
        await _ensureUserDoc(result.user);
      },
      verificationFailed: onError,
      codeSent: (verificationId, _) => onCodeSent(verificationId),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  /// Phone OTP — step 2: confirm code
  Future<UserCredential> confirmPhoneOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final result = await _auth.signInWithCredential(credential);
    await _ensureUserDoc(result.user);
    return result;
  }

  /// Email OTP / magic link — step 1: send link
  Future<void> sendEmailMagicLink(String email) async {
    final actionCodeSettings = ActionCodeSettings(
      url: 'https://shikhaya.page.link/login', // configure a real Dynamic Link
      handleCodeInApp: true,
      androidPackageName: 'com.shikhaya.app',
      androidInstallApp: true,
      androidMinimumVersion: '1',
    );
    await _auth.sendSignInLinkToEmail(
      email: email,
      actionCodeSettings: actionCodeSettings,
    );
  }

  /// Email OTP / magic link — step 2: complete sign-in from the link
  Future<UserCredential?> completeEmailLinkSignIn({
    required String email,
    required String emailLink,
  }) async {
    if (!_auth.isSignInWithEmailLink(emailLink)) return null;
    final result =
        await _auth.signInWithEmailLink(email: email, emailLink: emailLink);
    await _ensureUserDoc(result.user);
    return result;
  }

  /// Creates the user's Firestore profile document on first login only.
  Future<void> _ensureUserDoc(User? user) async {
    if (user == null) return;
    final ref = _db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'uid': user.uid,
        'email': user.email,
        'displayName': user.displayName,
        'xp': 0,
        'streak': 0,
        'createdAt': FieldValue.serverTimestamp(),
        'lastActive': FieldValue.serverTimestamp(),
      });
    } else {
      await ref.update({'lastActive': FieldValue.serverTimestamp()});
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await FacebookAuth.instance.logOut();
    await _auth.signOut();
  }
}
