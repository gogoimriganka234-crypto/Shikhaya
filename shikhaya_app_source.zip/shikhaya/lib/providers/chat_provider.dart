import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/chat_message.dart';
import '../services/chat_service.dart';

class ChatProvider extends ChangeNotifier {
  final ChatService _chatService = ChatService();
  StreamSubscription? _sub;

  List<ChatMessage> messages = [];
  bool sending = false;
  String? errorMessage;

  ChatProvider() {
    _sub = _chatService.messageStream().listen((msgs) {
      messages = msgs;
      notifyListeners();
    });
  }

  Future<void> send(String text, {String? subjectId}) async {
    if (text.trim().isEmpty) return;
    sending = true;
    errorMessage = null;
    notifyListeners();
    try {
      await _chatService.sendMessage(text.trim(), subjectId: subjectId);
    } catch (e) {
      errorMessage = 'Could not get a response. Please try again.';
    } finally {
      sending = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
