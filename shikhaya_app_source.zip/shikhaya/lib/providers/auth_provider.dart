import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

enum AuthStatus { unknown, signedOut, signedIn }

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  AuthStatus status = AuthStatus.unknown;
  User? user;
  String? errorMessage;
  bool isLoading = false;

  AuthProvider() {
    _authService.authStateChanges.listen((u) {
      user = u;
      status = u == null ? AuthStatus.signedOut : AuthStatus.signedIn;
      notifyListeners();
    });
  }

  Future<void> _run(Future<void> Function() action) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await action();
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message ?? 'Authentication failed';
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signInWithGoogle() => _run(() => _authService.signInWithGoogle());
  Future<void> signInWithFacebook() => _run(() => _authService.signInWithFacebook());

  Future<void> sendPhoneOtp(String phone, void Function(String) onCodeSent) => _run(
        () => _authService.sendPhoneOtp(
          phoneNumber: phone,
          onCodeSent: onCodeSent,
          onError: (e) => errorMessage = e.message,
        ),
      );

  Future<void> confirmPhoneOtp(String verificationId, String code) => _run(
        () => _authService.confirmPhoneOtp(
          verificationId: verificationId,
          smsCode: code,
        ),
      );

  Future<void> sendEmailMagicLink(String email) =>
      _run(() => _authService.sendEmailMagicLink(email));

  Future<void> signOut() => _run(() => _authService.signOut());
}
