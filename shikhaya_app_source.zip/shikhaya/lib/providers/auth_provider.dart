import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

enum AuthStatus { unknown, signedOut, signedIn }

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  AuthStatus status = AuthStatus.unknown;
  User? user;
  String? role; // 'admin' | 'student' | null (still loading)
  String? errorMessage;
  bool isLoading = false;

  bool get isAdmin => role == 'admin';

  AuthProvider() {
    _authService.authStateChanges.listen((u) async {
      user = u;
      status = u == null ? AuthStatus.signedOut : AuthStatus.signedIn;
      role = null;
      notifyListeners();

      if (u != null) {
        await _loadRole(u);
      }
    });
  }

  Future<void> _loadRole(User u) async {
    try {
      // Force refresh once so a just-assigned role claim is picked up
      // immediately rather than waiting for natural token expiry.
      var result = await u.getIdTokenResult(true);
      var claimRole = result.claims?['role'] as String?;

      if (claimRole == null) {
        // Claim not set yet (Cloud Function may still be running) —
        // ask the backend to assign it now, then refresh again.
        try {
          await FirebaseFunctions.instance.httpsCallable('refreshRole').call();
          result = await u.getIdTokenResult(true);
          claimRole = result.claims?['role'] as String?;
        } catch (_) {}
      }

      role = claimRole ?? 'student';
    } catch (_) {
      role = 'student';
    }
    notifyListeners();
  }

  Future<void> _run(Future<void> Function() action) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await action();
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message ?? 'Authentication failed';
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signInWithGoogle() => _run(() => _authService.signInWithGoogle());
  Future<void> signInWithFacebook() => _run(() => _authService.signInWithFacebook());

  Future<void> sendPhoneOtp(String phone, void Function(String) onCodeSent) => _run(
        () => _authService.sendPhoneOtp(
          phoneNumber: phone,
          onCodeSent: onCodeSent,
          onError: (e) => errorMessage = e.message,
        ),
      );

  Future<void> confirmPhoneOtp(String verificationId, String code) => _run(
        () => _authService.confirmPhoneOtp(
          verificationId: verificationId,
          smsCode: code,
        ),
      );

  Future<void> sendEmailMagicLink(String email) =>
      _run(() => _authService.sendEmailMagicLink(email));

  Future<void> signOut() => _run(() => _authService.signOut());
}
