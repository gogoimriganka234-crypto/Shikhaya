class Citation {
  final String chapterTitle;
  final int pageNumber;

  Citation({required this.chapterTitle, required this.pageNumber});

  factory Citation.fromMap(Map<String, dynamic> map) => Citation(
        chapterTitle: map['chapterTitle'] ?? '',
        pageNumber: map['pageNumber'] ?? 0,
      );
}

enum MessageRole { user, ai }

class ChatMessage {
  final String id;
  final MessageRole role;
  final String text;
  final List<Citation> citations;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.role,
    required this.text,
    this.citations = const [],
    required this.timestamp,
  });

  factory ChatMessage.fromMap(String id, Map<String, dynamic> map) {
    return ChatMessage(
      id: id,
      role: map['role'] == 'ai' ? MessageRole.ai : MessageRole.user,
      text: map['text'] ?? '',
      citations: (map['citations'] as List<dynamic>? ?? [])
          .map((c) => Citation.fromMap(Map<String, dynamic>.from(c)))
          .toList(),
      timestamp: DateTime.tryParse(map['timestamp']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}
