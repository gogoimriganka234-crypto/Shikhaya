import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

/// Will list subjects/chapters/PDFs once the content pipeline is connected.
class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PDF Library')),
      body: const Center(
        child: Text(
          'Subjects & chapters will appear here\nonce content is uploaded.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
      ),
    );
  }
}
