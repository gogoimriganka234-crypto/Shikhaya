import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/bottom_glow_scaffold.dart';
import '../../widgets/chat_bubble.dart';
import '../../widgets/chat_input_bar.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  void _send() {
    final chat = context.read<ChatProvider>();
    final text = _controller.text;
    _controller.clear();
    chat.send(text);
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();

    return BottomGlowScaffold(
      appBar: AppBar(title: const Text('Shikhaya AI')),
      child: chat.messages.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Ask anything from your syllabus PDFs.\nAnswers come only from your books.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            )
          : ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 260),
              itemCount: chat.messages.length,
              itemBuilder: (_, i) => ChatBubble(message: chat.messages[i]),
            ),
      bottomBar: ChatInputBar(
        controller: _controller,
        onSend: _send,
        sending: chat.sending,
      ),
    );
  }
}
