import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../services/admin_service.dart';

class SubjectEditorSheet extends StatefulWidget {
  final Map<String, dynamic>? existing;
  const SubjectEditorSheet({super.key, this.existing});

  @override
  State<SubjectEditorSheet> createState() => _SubjectEditorSheetState();
}

class _SubjectEditorSheetState extends State<SubjectEditorSheet> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _limit;
  late bool _active;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?['name'] ?? '');
    _description = TextEditingController(text: e?['description'] ?? '');
    _limit = TextEditingController(
        text: e?['dailyQuestionLimit'] != null ? '${e!['dailyQuestionLimit']}' : '');
    _active = (e?['status'] ?? 'draft') == 'active';
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'Subject name is required');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await AdminService().setSubject(
        id: widget.existing?['id'],
        name: _name.text.trim(),
        description: _description.text.trim(),
        status: _active ? 'active' : 'draft',
        dailyQuestionLimit: _limit.text.trim().isEmpty ? null : int.tryParse(_limit.text.trim()),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'Failed to save: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _delete() async {
    if (widget.existing == null) return;
    setState(() => _saving = true);
    try {
      await AdminService().deleteDoc('subjects', widget.existing!['id']);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'Failed to delete: $e');
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existing != null;
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(isEditing ? 'Edit Subject' : 'New Subject',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Subject name', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _description,
            decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()),
            maxLines: 2,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _limit,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Daily AI question limit (optional)',
              hintText: 'e.g. 20 — leave blank for unlimited',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Active (visible to students)'),
            value: _active,
            activeColor: AppColors.orange,
            onChanged: (v) => setState(() => _active = v),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12.5)),
            ),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(
                          height: 18, width: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Save'),
                ),
              ),
              if (isEditing) ...[
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: _saving ? null : _delete,
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                  child: const Text('Delete'),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
