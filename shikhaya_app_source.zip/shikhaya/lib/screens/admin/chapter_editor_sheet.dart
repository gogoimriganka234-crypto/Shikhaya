import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../services/admin_service.dart';

class ChapterEditorSheet extends StatefulWidget {
  final String subjectId;
  final Map<String, dynamic>? existing;
  const ChapterEditorSheet({super.key, required this.subjectId, this.existing});

  @override
  State<ChapterEditorSheet> createState() => _ChapterEditorSheetState();
}

class _ChapterEditorSheetState extends State<ChapterEditorSheet> {
  late final TextEditingController _title;
  late final TextEditingController _order;
  late bool _active;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?['title'] ?? '');
    _order = TextEditingController(text: e?['order'] != null ? '${e!['order']}' : '0');
    _active = (e?['status'] ?? 'draft') == 'active';
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty) {
      setState(() => _error = 'Chapter title is required');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await AdminService().setChapter(
        id: widget.existing?['id'],
        subjectId: widget.subjectId,
        title: _title.text.trim(),
        order: int.tryParse(_order.text.trim()) ?? 0,
        status: _active ? 'active' : 'draft',
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'Failed to save: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _delete() async {
    if (widget.existing == null) return;
    setState(() => _saving = true);
    try {
      await AdminService().deleteDoc('chapters', widget.existing!['id']);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'Failed to delete: $e');
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existing != null;
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(isEditing ? 'Edit Chapter' : 'New Chapter',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextField(
            controller: _title,
            decoration: const InputDecoration(labelText: 'Chapter title', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _order,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Order (e.g. 1, 2, 3...)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Active (visible to students)'),
            value: _active,
            activeColor: AppColors.orange,
            onChanged: (v) => setState(() => _active = v),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12.5)),
            ),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(
                          height: 18, width: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Save'),
                ),
              ),
              if (isEditing) ...[
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: _saving ? null : _delete,
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                  child: const Text('Delete'),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
