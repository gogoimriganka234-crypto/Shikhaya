import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../services/admin_service.dart';
import 'chapter_editor_sheet.dart';
import 'upload_pdf_sheet.dart';

class ChaptersScreen extends StatelessWidget {
  final String subjectId;
  final String subjectName;
  const ChaptersScreen({super.key, required this.subjectId, required this.subjectName});

  @override
  Widget build(BuildContext context) {
    final admin = AdminService();

    return Scaffold(
      appBar: AppBar(title: Text(subjectName)),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.orange,
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => ChapterEditorSheet(subjectId: subjectId),
        ),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: admin.chaptersStream(subjectId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator(color: AppColors.orange));
          }
          final chapters = snapshot.data!;
          if (chapters.isEmpty) {
            return const Center(
              child: Text('No chapters yet. Tap + to add one.',
                  style: TextStyle(color: AppColors.muted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: chapters.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final c = chapters[i];
              return ListTile(
                tileColor: AppColors.surface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                title: Text(c['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                  (c['status'] ?? 'draft') == 'active' ? '🟢 Active' : '🟡 Draft',
                  style: const TextStyle(fontSize: 12.5),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.upload_file_rounded, color: AppColors.orange),
                  tooltip: 'Upload PDF',
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => UploadPdfSheet(subjectId: subjectId, chapterId: c['id']),
                  ),
                ),
                onLongPress: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => ChapterEditorSheet(subjectId: subjectId, existing: c),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
