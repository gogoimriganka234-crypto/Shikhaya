import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/theme/app_colors.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final db = FirebaseFirestore.instance;

    return Scaffold(
      appBar: AppBar(title: const Text('Admin Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Overview',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _StatRow(
              children: [
                _StatCard(
                  label: 'Subjects',
                  stream: db.collection('subjects').snapshots(),
                ),
                _StatCard(
                  label: 'Chapters',
                  stream: db.collection('chapters').snapshots(),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _StatRow(
              children: [
                _StatCard(
                  label: 'Students',
                  stream: db.collection('users').where('role', isEqualTo: 'student').snapshots(),
                ),
                _StatCard(
                  label: 'PDF Chunks Indexed',
                  stream: db.collection('pdf_chunks').snapshots(),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: AppColors.orange),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Upload a PDF from the Subjects tab to add syllabus content. '
                      'It will be indexed automatically for AI Chat within a minute.',
                      style: TextStyle(fontSize: 13, color: AppColors.text),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final List<Widget> children;
  const _StatRow({required this.children});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (int i = 0; i < children.length; i++) ...[
          if (i > 0) const SizedBox(width: 12),
          Expanded(child: children[i]),
        ],
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final Stream<QuerySnapshot> stream;
  const _StatCard({required this.label, required this.stream});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: stream,
      builder: (context, snapshot) {
        final count = snapshot.data?.docs.length;
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                count?.toString() ?? '–',
                style: const TextStyle(
                    fontSize: 26, fontWeight: FontWeight.bold, color: AppColors.orange),
              ),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 12.5, color: AppColors.muted)),
            ],
          ),
        );
      },
    );
  }
}
