import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../services/admin_service.dart';
import 'chapters_screen.dart';
import 'subject_editor_sheet.dart';

class SubjectsScreen extends StatelessWidget {
  const SubjectsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final admin = AdminService();

    return Scaffold(
      appBar: AppBar(title: const Text('Subjects')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.orange,
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => const SubjectEditorSheet(),
        ),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: admin.subjectsStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator(color: AppColors.orange));
          }
          final subjects = snapshot.data!;
          if (subjects.isEmpty) {
            return const Center(
              child: Text('No subjects yet. Tap + to add one.',
                  style: TextStyle(color: AppColors.muted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: subjects.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final s = subjects[i];
              final status = s['status'] ?? 'draft';
              return ListTile(
                tileColor: AppColors.surface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                title: Text(s['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                  '${status == 'active' ? '🟢 Active' : '🟡 Draft'}'
                  '${s['dailyQuestionLimit'] != null ? ' · Limit: ${s['dailyQuestionLimit']}/day' : ''}',
                  style: const TextStyle(fontSize: 12.5),
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChaptersScreen(subjectId: s['id'], subjectName: s['name']),
                  ),
                ),
                onLongPress: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => SubjectEditorSheet(existing: s),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
