import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../core/theme/app_colors.dart';
import '../../services/admin_service.dart';

class UploadPdfSheet extends StatefulWidget {
  final String subjectId;
  final String chapterId;
  const UploadPdfSheet({super.key, required this.subjectId, required this.chapterId});

  @override
  State<UploadPdfSheet> createState() => _UploadPdfSheetState();
}

class _UploadPdfSheetState extends State<UploadPdfSheet> {
  File? _file;
  String? _fileName;
  final _titleController = TextEditingController();
  bool _uploading = false;
  String? _error;
  bool _done = false;

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null && result.files.single.path != null) {
      setState(() {
        _file = File(result.files.single.path!);
        _fileName = result.files.single.name;
        if (_titleController.text.isEmpty) {
          _titleController.text = _fileName!.replaceAll('.pdf', '');
        }
      });
    }
  }

  Future<void> _upload() async {
    if (_file == null || _titleController.text.trim().isEmpty) {
      setState(() => _error = 'Choose a PDF and enter a title');
      return;
    }
    setState(() {
      _uploading = true;
      _error = null;
    });
    try {
      final bookId = _titleController.text.trim().replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
      await AdminService().uploadPdf(
        file: _file!,
        subjectId: widget.subjectId,
        chapterId: widget.chapterId,
        bookId: bookId,
      );
      setState(() => _done = true);
    } catch (e) {
      setState(() => _error = 'Upload failed: $e');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Upload Syllabus PDF',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          if (_done) ...[
            const Icon(Icons.check_circle_rounded, color: Colors.green, size: 40),
            const SizedBox(height: 8),
            const Text(
              'Uploaded! The AI index will update automatically within a minute.',
              style: TextStyle(color: AppColors.text),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Done'),
            ),
          ] else ...[
            OutlinedButton.icon(
              onPressed: _pickFile,
              icon: const Icon(Icons.attach_file_rounded),
              label: Text(_fileName ?? 'Choose PDF file'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Book/PDF title', border: OutlineInputBorder()),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12.5)),
              ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _uploading ? null : _upload,
                child: _uploading
                    ? const SizedBox(
                        height: 18, width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Upload'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
