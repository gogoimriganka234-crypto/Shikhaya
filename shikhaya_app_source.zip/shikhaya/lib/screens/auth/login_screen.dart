import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/auth_provider.dart';
import 'phone_otp_screen.dart';
import 'email_otp_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // ===== TOP ORB SECTION =====
          SizedBox(
            height: 400,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(color: AppColors.darkOrbBg),
                Positioned(
                  top: -170,
                  left: -100,
                  child: Container(
                    width: 520,
                    height: 520,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        center: const Alignment(-0.35, -0.4),
                        radius: 0.9,
                        colors: [
                          Colors.white.withOpacity(0.5),
                          AppColors.orangeLight.withOpacity(0.35),
                          const Color(0xFF1A0D00),
                          AppColors.darkOrbBg,
                        ],
                        stops: const [0.0, 0.15, 0.55, 1.0],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.orange.withOpacity(0.5),
                          blurRadius: 90,
                          spreadRadius: 20,
                        ),
                      ],
                      border: Border.all(
                        color: AppColors.orange.withOpacity(0.5),
                        width: 3,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 62,
                  left: 0,
                  right: 0,
                  child: Column(
                    children: [
                      RichText(
                        text: TextSpan(
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.4,
                          ),
                          children: [
                            const TextSpan(
                                text: 'Shikhaya ', style: TextStyle(color: Colors.white)),
                            TextSpan(
                                text: 'শিক্ষা',
                                style: TextStyle(color: AppColors.orangeLight)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Learn only from your syllabus',
                        style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ===== WHITE SHEET =====
          Expanded(
            child: Transform.translate(
              offset: const Offset(0, -34),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                ),
                padding: const EdgeInsets.fromLTRB(24, 14, 24, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFE6DB),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                    const Text('Welcome to Shikhaya',
                        style: TextStyle(
                            fontSize: 21, fontWeight: FontWeight.w800, color: AppColors.text)),
                    const SizedBox(height: 4),
                    const Text('Pick an option to sign in and start learning',
                        style: TextStyle(fontSize: 13, color: AppColors.muted)),
                    const SizedBox(height: 22),

                    if (auth.errorMessage != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(auth.errorMessage!,
                            style: const TextStyle(color: Colors.red, fontSize: 12.5)),
                      ),

                    _optionTile(
                      icon: Icons.g_mobiledata_rounded,
                      label: 'Continue with Google',
                      onTap: auth.isLoading ? null : auth.signInWithGoogle,
                    ),
                    _optionTile(
                      icon: Icons.facebook_rounded,
                      label: 'Continue with Facebook',
                      onTap: auth.isLoading ? null : auth.signInWithFacebook,
                    ),

                    Row(children: const [
                      Expanded(child: Divider(color: Color(0xFFF1E9DF))),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Text('OR', style: TextStyle(fontSize: 11.5, color: AppColors.muted)),
                      ),
                      Expanded(child: Divider(color: Color(0xFFF1E9DF))),
                    ]),
                    const SizedBox(height: 6),

                    _optionTile(
                      icon: Icons.smartphone_rounded,
                      label: 'Continue with Phone OTP',
                      onTap: auth.isLoading
                          ? null
                          : () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => const PhoneOtpScreen())),
                    ),
                    _optionTile(
                      icon: Icons.mail_outline_rounded,
                      label: 'Continue with Email OTP',
                      onTap: auth.isLoading
                          ? null
                          : () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => const EmailOtpScreen())),
                      primary: true,
                    ),

                    if (auth.isLoading)
                      const Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Center(
                            child: CircularProgressIndicator(color: AppColors.orange)),
                      ),

                    const Spacer(),
                    const Center(
                      child: Text(
                        "By continuing, you agree to Shikhaya's Terms & Privacy Policy",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 11, color: AppColors.muted),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _optionTile({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
    bool primary = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: primary
                ? const LinearGradient(colors: [AppColors.orange, AppColors.orangeSoft])
                : null,
            color: primary ? null : AppColors.surface,
            border: primary ? null : Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: primary ? Colors.white.withOpacity(0.25) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, size: 20, color: primary ? Colors.white : AppColors.orange),
              ),
              const SizedBox(width: 14),
              Text(
                label,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  color: primary ? Colors.white : AppColors.text,
                ),
              ),
              const Spacer(),
              Icon(Icons.chevron_right_rounded, color: primary ? Colors.white : AppColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}
