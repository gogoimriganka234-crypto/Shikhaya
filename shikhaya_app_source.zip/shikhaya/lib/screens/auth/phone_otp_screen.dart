import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/auth_provider.dart';

class PhoneOtpScreen extends StatefulWidget {
  const PhoneOtpScreen({super.key});

  @override
  State<PhoneOtpScreen> createState() => _PhoneOtpScreenState();
}

class _PhoneOtpScreenState extends State<PhoneOtpScreen> {
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  String? _verificationId;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Phone Sign-In')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_verificationId == null) ...[
              const Text('Enter your phone number',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  hintText: '+91XXXXXXXXXX',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: auth.isLoading
                    ? null
                    : () => auth.sendPhoneOtp(_phoneController.text.trim(), (id) {
                          setState(() => _verificationId = id);
                        }),
                child: const Text('Send OTP'),
              ),
            ] else ...[
              const Text('Enter the 6-digit code',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              TextField(
                controller: _codeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: '123456',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: auth.isLoading
                    ? null
                    : () => auth.confirmPhoneOtp(_verificationId!, _codeController.text.trim()),
                child: const Text('Verify & Continue'),
              ),
            ],
            if (auth.errorMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(auth.errorMessage!, style: const TextStyle(color: Colors.red)),
              ),
            if (auth.isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 16),
                child: CircularProgressIndicator(color: AppColors.orange),
              ),
          ],
        ),
      ),
    );
  }
}
