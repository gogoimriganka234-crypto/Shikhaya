import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/auth_provider.dart';

class EmailOtpScreen extends StatefulWidget {
  const EmailOtpScreen({super.key});

  @override
  State<EmailOtpScreen> createState() => _EmailOtpScreenState();
}

class _EmailOtpScreenState extends State<EmailOtpScreen> {
  final _emailController = TextEditingController();
  bool _linkSent = false;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Email Sign-In')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!_linkSent) ...[
              const Text('Enter your email address',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  hintText: 'you@example.com',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: auth.isLoading
                    ? null
                    : () async {
                        await auth.sendEmailMagicLink(_emailController.text.trim());
                        // Save the email locally (e.g. shared_preferences) so
                        // completeEmailLinkSignIn() can use it when the user
                        // taps the link from their inbox.
                        setState(() => _linkSent = true);
                      },
                child: const Text('Send Sign-In Link'),
              ),
            ] else
              Text(
                'A sign-in link has been sent to ${_emailController.text}. '
                'Open it on this device to finish signing in.',
                style: const TextStyle(fontSize: 14, color: AppColors.muted),
              ),
            if (auth.errorMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(auth.errorMessage!, style: const TextStyle(color: Colors.red)),
              ),
          ],
        ),
      ),
    );
  }
}
