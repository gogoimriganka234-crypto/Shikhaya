import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/auth_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 34,
              backgroundColor: AppColors.surface,
              child: const Icon(Icons.person, size: 34, color: AppColors.orange),
            ),
            const SizedBox(height: 12),
            Text(auth.user?.displayName ?? auth.user?.email ?? 'Student',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(auth.user?.email ?? '', style: const TextStyle(color: AppColors.muted)),
            const SizedBox(height: 24),
            OutlinedButton(
              onPressed: () => auth.signOut(),
              child: const Text('Sign out'),
            ),
          ],
        ),
      ),
    );
  }
}
