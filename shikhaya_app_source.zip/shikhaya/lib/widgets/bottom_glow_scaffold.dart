import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// Wraps a screen body + bottom bar with the signature bottom orange glow.
class BottomGlowScaffold extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget child;
  final Widget bottomBar;

  const BottomGlowScaffold({
    super.key,
    this.appBar,
    required this.child,
    required this.bottomBar,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar,
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          Positioned.fill(child: child),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 260,
            child: IgnorePointer(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(0, 1.4),
                    radius: 1.1,
                    colors: [
                      Color(0x8CFF6F00),
                      Color(0x47FF6F00),
                      Color(0x14FF6F00),
                      Color(0x00FF6F00),
                    ],
                    stops: [0.0, 0.35, 0.6, 1.0],
                  ),
                ),
              ),
            ),
          ),
          Positioned(left: 0, right: 0, bottom: 0, child: bottomBar),
        ],
      ),
    );
  }
}
